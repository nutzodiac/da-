﻿Public Class M02

    Public M02price As Integer
    Private Sub M02_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox1.Text = Form1.Mn2
        TextBox2.Text = Form1.desc2
        TextBox3.Text = Form1.price2.ToString()

        TextBox1.Enabled = False
        TextBox2.Enabled = False
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            M02price = CInt(TextBox3.Text)
            Form1.price2 = M02price
            MessageBox.Show("แก้ไขราคาสำเร็จ", "อัพเดท", MessageBoxButtons.OK, MessageBoxIcon.Information)
            TextBox3.Text = M02price
            Me.Close()
        Catch ex As Exception
            MessageBox.Show("ตรวจสอบราคาที่ต้องการจะแก้ไข", "อัพเดท", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End Try
    End Sub
End Class