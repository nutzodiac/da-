﻿Public Class M01

    Public M01price As Integer

    Public Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox1.Text = Form1.Mn1
        TextBox2.Text = Form1.desc
        TextBox3.Text = Form1.price1.ToString()

        TextBox1.Enabled = False
        TextBox2.Enabled = False

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try

        
        M01price = CInt(TextBox3.Text)
        Form1.price1 = M01price
            MessageBox.Show("แก้ไขราคาสำเร็จ", "อัพเดท", MessageBoxButtons.OK, MessageBoxIcon.Information)
            TextBox3.Text = M01price
            Me.Close()
        Catch ex As Exception
            MessageBox.Show("ตรวจสอบราคาที่ต้องการจะแก้ไข", "อัพเดท", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End Try
    End Sub

    
End Class