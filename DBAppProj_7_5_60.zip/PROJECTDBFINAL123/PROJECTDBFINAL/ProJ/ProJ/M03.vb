﻿Public Class M03
    Public M03price As Integer
    Private Sub M03_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox1.Text = Form1.Mn3
        TextBox2.Text = Form1.desc3
        TextBox3.Text = Form1.price3.ToString()

        TextBox1.Enabled = False
        TextBox2.Enabled = False
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
      
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            M03price = CInt(TextBox3.Text)
            Form1.price3 = M03price
            MessageBox.Show("แก้ไขราคาสำเร็จ", "อัพเดท", MessageBoxButtons.OK, MessageBoxIcon.Information)
            TextBox3.Text = M03price
            Me.Close()
        Catch ex As Exception
            MessageBox.Show("ตรวจสอบราคาที่ต้องการจะแก้ไข", "อัพเดท", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End Try
    End Sub
End Class