﻿Imports System.Data.SqlClient
Imports System.Data

Public Class Form1

    Dim Strconn As String = "Data Source=10.199.66.228; Initial Catalog=std5830211249; Uid=std5830211249; Pwd=std5830211249;"
    Public ObjConn As New SqlConnection(Strconn)
    Dim ds As DataSet
    Dim da As SqlDataAdapter
    Dim Strdel As String
    Public strcell As String

    'ส่วนเปลี่ยนสีเวลาคลิกปุ่ม
    Dim status As Integer = 1
    Public price1 As Integer = 200
    Public price2 As Integer = 500
    Public price3 As Integer
    Public price4 As Integer
    Public price5 As Integer

    Public Mn As String
    Public Mn1 As String
    Public Mn2 As String
    Public Mn3 As String
    Public Mn4 As String
    Public Mn5 As String
    Public billst As Integer  'บิลจะแอดไปเรื่อยๆ 
    Public desc As String
    Public desc2 As String
    Public desc3 As String
    Public desc4 As String
    Public desc5 As String
    Public income As Integer
    Public Sumall As Integer
    Public Payout As Integer




    Public Sub show_data()

        Dim Strquery As String
        Strquery = "Select price FROM Menu_Table Where Menu_ID='" + Mn + "'"

        da = New SqlClient.SqlDataAdapter(Strquery, ObjConn)
        ds = New DataSet
        da.Fill(ds, "BILL")
        DataGridView1.DataMember = "BILL"
        DataGridView1.DataSource = ds
    End Sub


    
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load





        Txtname.Text = ""
        TxtCar.Text = ""
        Txttel.Text = ""

        DataGridView1.ColumnCount = 5

        DataGridView1.Columns(0).Width = 50
        DataGridView1.Columns(1).Width = 100
        DataGridView1.Columns(2).Width = 100
        DataGridView1.Columns(3).Width = 50
        DataGridView1.Columns(4).Width = 100


        DataGridView1.Columns(4).Name = "ทะเบียนรถ"
        DataGridView1.Columns(3).Name = "ชื่อ"
        DataGridView1.Columns(2).Name = "เบอร์โทรศัพท์"
        DataGridView1.Columns(1).Name = "รายละเอียด"
        DataGridView1.Columns(0).Name = "ราคา"

        ' DateTimePicker1.Format = DateTimePickerFormat.Custom
        ' DateTimePicker1.CustomFormat = "dd/MM/yyyy"
        Label10.Text = DateTimePicker1.Value.ToLongDateString()


        Label11.Text = billst.ToString()



    End Sub





    'ส่วนเอาข้อมูลเข้า DATAGRIDVIEW

    Private Sub BtnAdd_Click(sender As Object, e As EventArgs)



    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If status = 1 Then
            Button1.BackColor = Color.LightGreen
            status = 0
        ElseIf status = 0 Then
            Button1.BackColor = Color.White
            status = 1
        End If

        price1 = price1
        Mn1 = "M01"
        desc = "ล้างสี-ดูดฝุ่น"

        Dim row As String() = New String() {price1.ToString, desc, Txttel.Text, Txtname.Text, TxtCar.Text}
        DataGridView1.Rows.Add(row)
        Button1.BackColor = Color.White
        Button2.BackColor = Color.White
        Button3.BackColor = Color.White
        Button4.BackColor = Color.White
        Button5.BackColor = Color.White
        Dim a As Integer = 0
        Dim sum As Integer = 0
        For i As Integer = 1 To DataGridView1.RowCount() - 1
            'ส่วนคำนวณ datagridview 
            Txtprice.Text = DataGridView1.Rows(i - 1).Cells("ราคา").Value
            Dim str = Txtprice.Text
            a = CDbl(str)
            sum += a

            'โชว์ตัวเลข
            Txtprice.Text = sum.ToString()
        Next

    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        If status = 1 Then
            Button2.BackColor = Color.LightGreen
            status = 0
        ElseIf status = 0 Then
            Button2.BackColor = Color.White
            status = 1
        End If
        price2 = price2
        Mn2 = "M02"
        desc = "ขัดเคลือบสีทั้งคัน"
        Dim row As String() = New String() {price2.ToString, desc, Txttel.Text, Txtname.Text, TxtCar.Text}
        DataGridView1.Rows.Add(row)
        Button1.BackColor = Color.White
        Button2.BackColor = Color.White
        Button3.BackColor = Color.White
        Button4.BackColor = Color.White
        Button5.BackColor = Color.White
        Dim a As Integer = 0
        Dim sum As Integer = 0
        For i As Integer = 1 To DataGridView1.RowCount() - 1
            'ส่วนคำนวณ datagridview 
            Txtprice.Text = DataGridView1.Rows(i - 1).Cells("ราคา").Value
            Dim str = Txtprice.Text
            a = CDbl(str)
            sum += a

            'โชว์ตัวเลข
            Txtprice.Text = sum.ToString()
        Next

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If status = 1 Then
            Button3.BackColor = Color.LightGreen
            status = 0
        ElseIf status = 0 Then
            Button3.BackColor = Color.White
            status = 1
        End If


        price3 = price3
        Mn3 = "M03"
        desc = "ล้างรถมอเตอร์ไซต์"
        Dim row As String() = New String() {price3.ToString, desc, Txttel.Text, Txtname.Text, TxtCar.Text}
        DataGridView1.Rows.Add(row)
        Button1.BackColor = Color.White
        Button2.BackColor = Color.White
        Button3.BackColor = Color.White
        Button4.BackColor = Color.White
        Button5.BackColor = Color.White
        Dim a As Integer = 0
        Dim sum As Integer = 0
        For i As Integer = 1 To DataGridView1.RowCount() - 1
            'ส่วนคำนวณ datagridview 
            Txtprice.Text = DataGridView1.Rows(i - 1).Cells("ราคา").Value
            Dim str = Txtprice.Text
            a = CDbl(str)
            sum += a

            'โชว์ตัวเลข
            Txtprice.Text = sum.ToString()
        Next
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If status = 1 Then
            Button4.BackColor = Color.LightGreen
            status = 0
        ElseIf status = 0 Then
            Button4.BackColor = Color.White
            status = 1
        End If
        price4 = price4
        Mn4 = "M04"
        desc = "ล้างห้องเครือง"

        Dim row As String() = New String() {price4.ToString, desc, Txttel.Text, Txtname.Text, TxtCar.Text}
        DataGridView1.Rows.Add(row)
        Button1.BackColor = Color.White
        Button2.BackColor = Color.White
        Button3.BackColor = Color.White
        Button4.BackColor = Color.White
        Button5.BackColor = Color.White
        Dim a As Integer = 0
        Dim sum As Integer = 0
        For i As Integer = 1 To DataGridView1.RowCount() - 1
            'ส่วนคำนวณ datagridview 
            Txtprice.Text = DataGridView1.Rows(i - 1).Cells("ราคา").Value
            Dim str = Txtprice.Text
            a = CDbl(str)
            sum += a

            'โชว์ตัวเลข
            Txtprice.Text = sum.ToString()
        Next
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        If status = 1 Then
            Button5.BackColor = Color.LightGreen
            status = 0
        ElseIf status = 0 Then
            Button5.BackColor = Color.White
            status = 1
        End If
        price5 = price5
        Mn5 = "M05"
        desc = "ล้างยางมะตอย"

        Dim row As String() = New String() {price5.ToString, desc, Txttel.Text, Txtname.Text, TxtCar.Text}
        DataGridView1.Rows.Add(row)
        Button1.BackColor = Color.White
        Button2.BackColor = Color.White
        Button3.BackColor = Color.White
        Button4.BackColor = Color.White
        Button5.BackColor = Color.White
        Dim a As Integer = 0
        Dim sum As Integer = 0
        For i As Integer = 1 To DataGridView1.RowCount() - 1
            'ส่วนคำนวณ datagridview 
            Txtprice.Text = DataGridView1.Rows(i - 1).Cells("ราคา").Value
            Dim str = Txtprice.Text
            a = CDbl(str)
            sum += a

            'โชว์ตัวเลข
            Txtprice.Text = sum.ToString()
        Next
    End Sub

    'โชว์ FROM 2
    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        Form2.Show()
    End Sub

    Private Sub btnDel_Click(sender As Object, e As EventArgs) Handles btnDel.Click
        Dim CurRow As Integer
        CurRow = Me.DataGridView1.CurrentRow.Index
        If Me.DataGridView1.Rows.Count <> 1 Then
            Dim Result As MsgBoxResult
            Result = MessageBox.Show("ต้องการลบรายการนี้หรือไม่", "ยืนยัน", MessageBoxButtons.YesNo,
                                    MessageBoxIcon.Question, MessageBoxDefaultButton.Button1)
            If Result = MsgBoxResult.Yes Then
                Me.DataGridView1.Rows.RemoveAt(CurRow)
            End If

            Dim a As Integer = 0
            Dim sum As Integer = 0
            For i As Integer = 1 To DataGridView1.RowCount() - 1
                'ส่วนคำนวณ datagridview 
                Txtprice.Text = DataGridView1.Rows(i - 1).Cells("ราคา").Value
                Dim str = Txtprice.Text
                a = CDbl(str)
                sum += a

                'โชว์ตัวเลข
                Txtprice.Text = sum.ToString()
                TextBox6.Text = Txtprice.Text
            Next


        End If

    End Sub
    'ลบข้อมูลใน DATAGRIDVIEW
    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs)
        Dim CurRow As Integer
        CurRow = Me.DataGridView1.CurrentRow.Index



    End Sub

    Private Sub Txtprice_TextChanged(sender As Object, e As EventArgs) Handles Txtprice.TextChanged
        TextBox4.Text = Txtprice.Text
    End Sub
    'ส่วนเพิ่มเข้าฐานข้อมูล 
    Private Sub btnadddata_Click(sender As Object, e As EventArgs) Handles btnadddata.Click
        Dim str As String
        If ObjConn.State = ConnectionState.Closed Then

            ObjConn.Open()
        End If
        str = "Insert Into Customer_table values ('" + TxtCar.Text + "','" + Txtname.Text + "','" + Txttel.Text + "');"
        

        Dim cmd = New SqlClient.SqlCommand(str, ObjConn)

        Try
            cmd.ExecuteNonQuery()


            MessageBox.Show("เพิ่มข้อมูลลูกค้าสำเร็จ", "ผลการดำเนินการ", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show("ทะเบียนซ้ำจ้าาาาาาา", "ตรวจสอบ", MessageBoxButtons.OK, MessageBoxIcon.Information)

        End Try



        Dim strbill As String

        Try
            For i As Integer = 1 To DataGridView1.RowCount() - 1
                Dim price As String = DataGridView1.Rows(i - 1).Cells("ราคา").Value.ToString()


                If (CInt(price.ToString()) < 0) Then


                Else

                    If DataGridView1.Rows(i - 1).Cells("รายละเอียด").Value.ToString() = "ล้างสี-ดูดฝุ่น" Then
                        Mn = "M01"
                        strbill = "Insert Into BILL_TABLE values ('" + Label11.Text + "','" + Label10.Text + "','" + TimeOfDay.TimeOfDay.ToString() + "','" + price + "','" + TxtCar.Text + "','" + "BT01" + "','" + Mn + "','" + "000" + "');"
                        Dim cmd2 = New SqlClient.SqlCommand(strbill, ObjConn)
                        cmd2.ExecuteNonQuery()
                        billst += 1
                        Label11.Text = billst.ToString()
                    ElseIf DataGridView1.Rows(i - 1).Cells("รายละเอียด").Value.ToString() = "ขัดเคลือบสีทั้งคัน" Then
                        Mn = "M02"
                        strbill = "Insert Into BILL_TABLE values ('" + Label11.Text + "','" + Label10.Text + "','" + TimeOfDay.TimeOfDay.ToString() + "','" + price + "','" + TxtCar.Text + "','" + "BT01" + "','" + Mn + "','" + "000" + "');"
                        Dim cmd2 = New SqlClient.SqlCommand(strbill, ObjConn)
                        cmd2.ExecuteNonQuery()
                        billst += 1
                        Label11.Text = billst.ToString()
                    ElseIf DataGridView1.Rows(i - 1).Cells("รายละเอียด").Value.ToString() = "ล้างรถมอเตอร์ไซต์" Then
                        Mn = "M03"
                        strbill = "Insert Into BILL_TABLE values ('" + Label11.Text + "','" + Label10.Text + "','" + TimeOfDay.TimeOfDay.ToString() + "','" + price + "','" + TxtCar.Text + "','" + "BT01" + "','" + Mn + "','" + "000" + "');"
                        Dim cmd2 = New SqlClient.SqlCommand(strbill, ObjConn)
                        cmd2.ExecuteNonQuery()
                        billst += 1
                        Label11.Text = billst.ToString()
                    ElseIf DataGridView1.Rows(i - 1).Cells("รายละเอียด").Value.ToString() = "ล้างห้องเครือง" Then
                        Mn = "M04"
                        strbill = "Insert Into BILL_TABLE values ('" + Label11.Text + "','" + Label10.Text + "','" + TimeOfDay.TimeOfDay.ToString() + "','" + price + "','" + TxtCar.Text + "','" + "BT01" + "','" + Mn + "','" + "000" + "');"
                        Dim cmd2 = New SqlClient.SqlCommand(strbill, ObjConn)
                        cmd2.ExecuteNonQuery()
                        billst += 1
                        Label11.Text = billst.ToString()
                    ElseIf DataGridView1.Rows(i - 1).Cells("รายละเอียด").Value.ToString() = "ล้างยางมะตอย" Then
                        Mn = "M05"
                        strbill = "Insert Into BILL_TABLE values ('" + Label11.Text + "','" + Label10.Text + "','" + TimeOfDay.TimeOfDay.ToString() + "','" + price + "','" + TxtCar.Text + "','" + "BT01" + "','" + Mn + "','" + "000" + "');"
                        Dim cmd2 = New SqlClient.SqlCommand(strbill, ObjConn)
                        cmd2.ExecuteNonQuery()
                        billst += 1
                        Label11.Text = billst.ToString()
                    End If
                End If

            Next


            MessageBox.Show("เพิ่มบิลสำเร็จ", "ผลการดำเนินการ", MessageBoxButtons.OK, MessageBoxIcon.Information)
            DataGridView1.Rows.Clear()

            Dim Add As String = TextBox6.Text
            Dim a As Integer
            a = CInt(Add)
            income += a


            Txtprice.Text = ""
            TextBox4.Text = ""
            TextBox5.Text = ""
            TextBox6.Text = ""
            TxtCar.Text = ""
            Txtname.Text = ""
            Txttel.Text = ""
            ObjConn.Close()

            Me.Refresh()

        Catch ex As Exception
            MessageBox.Show("กรุณาตรวจสอบรายการบิล", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Form3.Show()
    End Sub

    Private Sub Label10_TextChanged(sender As Object, e As EventArgs) Handles Label10.TextChanged
        billst = 1
    End Sub
    Private Sub TextBox5_MouseClick(sender As Object, e As MouseEventArgs) Handles TextBox5.MouseClick
        Try


            If TextBox5.Text = "" Then


            Else
                Dim sum2 As Integer
                Dim str As String = TextBox4.Text
                Dim a As Integer
                Dim str2 As String = TextBox5.Text
                Dim b As Integer
                a = CInt(str)
                b = CInt(str2)
                sum2 = a * b / 100
                sum2 = a - sum2
                TextBox6.Text = sum2.ToString()
                Txtprice.Text = sum2.ToString()
            End If
        Catch ex As Exception
            MessageBox.Show("กรุณาใส่จำวนให้ถูกต้อง", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End Try
    End Sub
    Private Sub Button1_MouseDown(sender As Object, e As MouseEventArgs) Handles Button1.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Right Then
            price1 = 200
            Mn1 = "M01"
            desc = "ล้างสี-ดูดฝุ่น"
            M01.Show()
        End If
    End Sub
    Private Sub Button2_MouseDown(sender As Object, e As MouseEventArgs) Handles Button2.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Right Then
            price2 = 500
            Mn2 = "M02"
            desc = "ขัดเคลือบสีทั้งคัน"
            M02.Show()
        End If
    End Sub
    Private Sub Button3_MouseDown(sender As Object, e As MouseEventArgs) Handles Button3.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Right Then
              price3 = 60
            Mn3 = "M03"
            desc = "ล้างรถมอเตอร์ไซต์"
            M03.Show()
        End If
    End Sub
    Private Sub Button4_MouseDown(sender As Object, e As MouseEventArgs) Handles Button4.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Right Then
         price4 = 200
            Mn4 = "M04"
            desc = "ล้างห้องเครือง"
            M04.Show()
        End If
    End Sub
    Private Sub Button5_MouseDown(sender As Object, e As MouseEventArgs) Handles Button5.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Right Then
          price5 = 500
            Mn5 = "M05"
            desc = "ล้างยางมะตอย"
            M05.Show()
        End If
    End Sub


End Class
