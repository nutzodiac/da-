﻿Imports System.Data.SqlClient
Imports System.Data


Public Class Form3



    Dim Strconn As String = "Data Source=10.199.66.228; Initial Catalog=std5830211249; Uid=std5830211249; Pwd=std5830211249;"
    Public ObjConn As New SqlConnection(Strconn)
    Dim ds As DataSet
    Dim da As SqlDataAdapter
    Public Pay As Integer


    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DateTimePicker1.Format = DateTimePickerFormat.Custom
        DateTimePicker1.CustomFormat = "dd/MM/yyyy"

        Label4.Text = DateTimePicker1.Value.ToLongDateString()
        Label5.Text = Form1.Label11.Text
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim str As String
        If ObjConn.State = ConnectionState.Closed Then

            ObjConn.Open()
        End If


        Try
            str = "Insert Into Customer_table values ('" + TextBox1.Text + "','" + " " + "','" + " " + "');"
            Dim cmd = New SqlClient.SqlCommand(str, ObjConn)
            cmd.ExecuteNonQuery()

        Catch ex As Exception

        End Try

        str = "Insert Into Bill_Table (Bill_ID, Bill_date,Bill_time,Amount,BT_ID,Emp_ID,Menu_ID,C_code) Values ('" + Form1.billst.ToString() + "','" + Label4.Text + "','" + TimeOfDay.TimeOfDay.ToString() + "','" + TextBox3.Text + "','" + "BT02" + "','" + txtemp.Text + "','" + "M00" + "','" + TextBox1.Text + "');"


        'INSERT INTO table_name (column1, column2, column3, ...)
        '           VALUES (value1, value2, value3, ...);


        Try
            Dim cmd = New SqlClient.SqlCommand(str, ObjConn)
            cmd.ExecuteNonQuery()
            Form1.billst += 1
            MessageBox.Show("เพิ่มบิลรายจ่ายสำเร็จ", "ผลการดำเนินการ", MessageBoxButtons.OK, MessageBoxIcon.Information)


            Dim Add As String = TextBox3.Text
            Dim a As Integer
            a = CInt(Add)
            Pay += a



            txtemp.Clear()
            TextBox1.Clear()
            TextBox3.Clear()



        Catch ex As Exception
            MessageBox.Show(ex.ToString())

        End Try



    End Sub

    Private Sub Form3_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Form1.Label11.Text = Form1.billst.ToString()
        Form1.Payout = Pay
        Form1.Sumall = Form1.income - Pay

    End Sub

    
End Class