﻿Public Class M04

    Public M04price As Integer
    Private Sub M04_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox1.Text = Form1.Mn4
        TextBox2.Text = Form1.desc4
        TextBox3.Text = Form1.price4.ToString()

        TextBox1.Enabled = False
        TextBox2.Enabled = False
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            M04price = CInt(TextBox3.Text)
            Form1.price4 = M04price
            MessageBox.Show("แก้ไขราคาสำเร็จ", "อัพเดท", MessageBoxButtons.OK, MessageBoxIcon.Information)
            TextBox3.Text = M04price
            Me.Close()
        Catch ex As Exception
            MessageBox.Show("ตรวจสอบราคาที่ต้องการจะแก้ไข", "อัพเดท", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End Try
    End Sub
End Class